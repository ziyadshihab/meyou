
import React, { useState, useEffect } from 'react';

// مدرسة العقدة للبنين - منصة اختبارات للفصول 5-9
const GRADES = ['5','6','7','8','9'];
const SUBJECTS = [
  'اللغة العربية',
  'اللغة الإنجليزية',
  'الرياضيات',
  'العلوم',
  'الاجتماعيات',
  'التربية الإسلامية',
  'الحاسوب',
  'الفن',
  'التربية البدنية'
];

const STARTER_DATA = () => {
  const data = {};
  GRADES.forEach(g => {
    data[g] = {};
    SUBJECTS.forEach(s => {
      data[g][s] = {
        lessons: Array.from({length:3}).map((_,i)=>({
          id: `${g}-${s}-L${i+1}`,
          title: `درس ${i+1} - ${s} (الصف ${g})`,
          summary: `محتوى مختصر للدرس ${i+1} في مادة ${s} للصف ${g}. استبدل هذا بالنص الفعلي للمقرر العماني.`
        })),
        tests: Array.from({length:3}).map((_,i)=>({
          id: `${g}-${s}-T${i+1}`,
          title: `اختبار قصير ${i+1} - ${s} (الصف ${g})`,
          questions: generateSampleQuestions(g,s,i+1)
        }))
      }
    })
  })
  return data;
}

function generateSampleQuestions(grade, subject, seed){
  return [
    {
      id: `q-${grade}-${subject}-${seed}-1`,
      type: 'mcq',
      question: `ما هو مفهوم أساسي في ${subject}؟ (مثال)`,
      options: ['خيار أ','خيار ب','خيار ج','خيار د'],
      answer: 0
    },
    {
      id: `q-${grade}-${subject}-${seed}-2`,
      type: 'tf',
      question: `هذا بيان صحيح أم خاطئ عن ${subject}؟`,
      answer: true
    },
    {
      id: `q-${grade}-${subject}-${seed}-3`,
      type: 'short',
      question: `اكتب جملة قصيرة تشرح نقطة في ${subject}.`,
      answer: 'مثال إجابة'
    }
  ]
}

const STORAGE_KEY = 'aloqda-school-data-v1';
const RESULTS_KEY = 'aloqda-school-results-v1';

export default function App(){
  const [data, setData] = useState(() => {
    try{
      const raw = localStorage.getItem(STORAGE_KEY);
      if(raw) return JSON.parse(raw);
    }catch(e){}
    return STARTER_DATA();
  });

  const [grade, setGrade] = useState('5');
  const [subject, setSubject] = useState(SUBJECTS[0]);
  const [view, setView] = useState('dashboard');
  const [selectedLesson, setSelectedLesson] = useState(null);
  const [selectedTest, setSelectedTest] = useState(null);
  const [results, setResults] = useState(() => {
    try{ return JSON.parse(localStorage.getItem(RESULTS_KEY)) || []; }catch(e){return []}
  });
  const [adminMode, setAdminMode] = useState(false);

  useEffect(()=>{ localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); },[data]);
  useEffect(()=>{ localStorage.setItem(RESULTS_KEY, JSON.stringify(results)); },[results]);

  function createRandomTest(numQuestions=10){
    const pool = [];
    const subjectObj = data[grade][subject];
    if(!subjectObj) return null;
    subjectObj.tests.forEach(t=> t.questions.forEach(q=> pool.push(q)));
    const shuffled = pool.sort(()=>Math.random()-0.5);
    const pick = shuffled.slice(0, Math.min(numQuestions, shuffled.length));
    const newTest = {
      id: `gen-${Date.now()}`,
      title: `اختبار مُنشأ عشوائياً - ${subject} - الصف ${grade}`,
      questions: pick
    }
    setSelectedTest(newTest);
    setView('take');
  }

  function startTest(test){
    setSelectedTest(test);
    setView('take');
  }

  function gradeTest(test, answers){
    let correct = 0; let total = test.questions.length;
    const detail = test.questions.map(q=>{
      const user = answers[q.id];
      let ok = false;
      if(q.type === 'mcq') ok = user === q.answer;
      else if(q.type === 'tf') ok = user === q.answer;
      else ok = (typeof user === 'string' && user.trim().length>0);
      if(ok) correct++;
      return {id:q.id, ok}
    })
    const score = Math.round((correct/total)*100);
    const record = {id: `res-${Date.now()}`, grade, subject, testTitle: test.title, score, date: new Date().toISOString(), detail};
    setResults(prev=>[record,...prev]);
    return record;
  }

  function addLesson(gradeKey, subjectKey, lesson){
    setData(prev=>{
      const copy = JSON.parse(JSON.stringify(prev));
      copy[gradeKey][subjectKey].lessons.push(lesson);
      return copy;
    });
  }
  function addTest(gradeKey, subjectKey, test){
    setData(prev=>{
      const copy = JSON.parse(JSON.stringify(prev));
      copy[gradeKey][subjectKey].tests.push(test);
      return copy;
    });
  }

  return (
    <div style={{padding:20,fontFamily:'sans-serif',direction:'rtl'}}>
      <header style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
        <div>
          <h1 style={{fontSize:24,fontWeight:700}}>مدرسة العقدة للبنين — منصة الاختبارات</h1>
          <p style={{color:'#6b7280'}}>منهج عماني — الصفوف: 5 حتى 9</p>
        </div>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          <select value={grade} onChange={e=>setGrade(e.target.value)}>
            {GRADES.map(g=> <option key={g} value={g}>الصف {g}</option>)}
          </select>
          <select value={subject} onChange={e=>setSubject(e.target.value)}>
            {SUBJECTS.map(s=> <option key={s} value={s}>{s}</option>)}
          </select>
          <button onClick={()=>setView('dashboard')}>الرئيسية</button>
          <button onClick={()=>setAdminMode(m=>!m)}>{adminMode? 'خروج من لوحة الإدارة' : 'دخول لوحة الإدارة'}</button>
        </div>
      </header>

      <main style={{display:'flex',gap:16}}>
        <aside style={{width:260,background:'#fff',padding:12,borderRadius:8}}>
          <h3>المواد — الصف {grade}</h3>
          <div style={{marginTop:8,display:'flex',flexDirection:'column',gap:6}}>
            {SUBJECTS.map(s=> (
              <button key={s} style={{textAlign:'right'}} onClick={()=>setSubject(s)}>{s}</button>
            ))}
          </div>

          <div style={{marginTop:12}}>
            <h4>اختبارات سريعة</h4>
            <div style={{marginTop:6,display:'flex',gap:6}}>
              <button onClick={()=>createRandomTest(5)}>5 أسئلة</button>
              <button onClick={()=>createRandomTest(10)}>10 أسئلة</button>
            </div>
          </div>

          <div style={{marginTop:12}}>
            <h4>سجل النتائج</h4>
            <div style={{marginTop:6,maxHeight:160,overflow:'auto'}}>
              {results.length===0 ? <p style={{color:'#6b7280'}}>لا توجد نتائج بعد.</p> : (
                results.slice(0,8).map(r=> (
                  <div key={r.id} style={{background:'#f3f4f6',padding:8,borderRadius:6,marginBottom:6}}>
                    <div style={{display:'flex',justifyContent:'space-between'}}>
                      <div style={{textAlign:'right'}}>
                        <div style={{fontWeight:600}}>{r.testTitle}</div>
                        <div style={{fontSize:12,color:'#6b7280'}}>{r.subject} — الصف {r.grade}</div>
                      </div>
                      <div style={{textAlign:'left'}}>
                        <div style={{fontWeight:700}}>{r.score}%</div>
                        <div style={{fontSize:11,color:'#9ca3af'}}>{new Date(r.date).toLocaleString('ar-EG')}</div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </aside>

        <section style={{flex:1}}>
          {view === 'dashboard' && (
            <div style={{background:'#fff',padding:16,borderRadius:8}}>
              <h2 style={{fontSize:18,fontWeight:700}}>الدرس والاختبارات — {subject} (الصف {grade})</h2>
              <div style={{display:'flex',gap:12,marginTop:12}}>
                <div style={{flex:1,border:'1px solid #e5e7eb',padding:12,borderRadius:6}}>
                  <h3>الدروس</h3>
                  <div style={{marginTop:8}}>
                    {data[grade] && data[grade][subject] && data[grade][subject].lessons.map(l=> (
                      <div key={l.id} style={{padding:8,borderRadius:6,background:'#f9fafb',marginBottom:8,display:'flex',justifyContent:'space-between'}}>
                        <div style={{textAlign:'right'}}>
                          <div style={{fontWeight:600}}>{l.title}</div>
                          <div style={{fontSize:13,color:'#6b7280'}}>{l.summary}</div>
                        </div>
                        <div>
                          <button onClick={()=>{setSelectedLesson(l); setView('lesson')}}>عرض</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div style={{flex:1,border:'1px solid #e5e7eb',padding:12,borderRadius:6}}>
                  <h3>الاختبارات</h3>
                  <div style={{marginTop:8}}>
                    {data[grade] && data[grade][subject] && data[grade][subject].tests.map(t=> (
                      <div key={t.id} style={{padding:8,borderRadius:6,background:'#f9fafb',marginBottom:8,display:'flex',justifyContent:'space-between'}}>
                        <div style={{textAlign:'right'}}>
                          <div style={{fontWeight:600}}>{t.title}</div>
                          <div style={{fontSize:13,color:'#6b7280'}}>أسئلة: {t.questions.length}</div>
                        </div>
                        <div>
                          <button onClick={()=>startTest(t)}>حل</button>
                          <button onClick={()=>{ setSelectedTest(t); setView('test')}}>تفاصيل</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {view === 'lesson' && selectedLesson && (
            <div style={{background:'#fff',padding:16,borderRadius:8}}>
              <button onClick={()=>setView('dashboard')}>&larr; العودة</button>
              <h2 style={{fontSize:18,fontWeight:700}}>{selectedLesson.title}</h2>
              <p style={{marginTop:8,color:'#374151'}}>{selectedLesson.summary}</p>
            </div>
          )}

          {view === 'test' && selectedTest && (
            <div style={{background:'#fff',padding:16,borderRadius:8}}>
              <button onClick={()=>setView('dashboard')}>&larr; العودة</button>
              <h2 style={{fontSize:18,fontWeight:700}}>تفاصيل: {selectedTest.title}</h2>
              <p style={{fontSize:13,color:'#6b7280',marginTop:6}}>أسئلة: {selectedTest.questions.length}</p>
              <ol style={{marginTop:12}}>
                {selectedTest.questions.map(q=> (
                  <li key={q.id} style={{marginBottom:8}}>
                    <div style={{fontWeight:600}}>{q.question}</div>
                    <div style={{color:'#6b7280',marginTop:4}}>
                      {q.type === 'mcq' && (<ul>{q.options.map((opt,idx)=><li key={idx}>{opt}{idx===q.answer ? ' ✅':''}</li>)}</ul>)}
                      {q.type === 'tf' && (<div>الجواب الصحيح: {q.answer ? 'صحيح':'خطأ'}</div>)}
                      {q.type === 'short' && (<div>إجابة نموذجية: {q.answer}</div>)}
                    </div>
                  </li>
                ))}
              </ol>
            </div>
          )}

          {view === 'take' && selectedTest && (
            <TakeTest key={selectedTest.id} test={selectedTest} onCancel={()=>setView('dashboard')} onSubmit={(answers)=>{
              const rec = gradeTest(selectedTest, answers);
              alert(`تم التصحيح — النتيجة: ${rec.score}%`);
              setView('dashboard');
            }} />
          )}

          {adminMode && (
            <AdminPanel grade={grade} subject={subject} onAddLesson={(lesson)=>addLesson(grade,subject,lesson)} onAddTest={(test)=>addTest(grade,subject,test)} data={data} />
          )}
        </section>
      </main>

      <footer style={{textAlign:'center',marginTop:24,color:'#9ca3af'}}>© مدرسة العقدة للبنين — منصة تجريبية.</footer>
    </div>
  )
}

function TakeTest({test, onCancel, onSubmit}){
  const [answers, setAnswers] = useState({});
  function setAns(qid, val){ setAnswers(a=>({...a, [qid]: val})) }
  return (
    <div style={{background:'#fff',padding:16,borderRadius:8}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
        <h2 style={{fontSize:18,fontWeight:700}}>حل: {test.title}</h2>
        <div>
          <button onClick={onCancel}>إلغاء</button>
          <button onClick={()=>onSubmit(answers)} style={{marginLeft:8}}>تسليم</button>
        </div>
      </div>
      <form onSubmit={e=>{e.preventDefault(); onSubmit(answers)}}>
        <ol style={{paddingInlineStart:18}}>
          {test.questions.map((q,idx)=> (
            <li key={q.id} style={{marginBottom:12}}>
              <div style={{fontWeight:600}}>{q.question}</div>
              <div style={{marginTop:6}}>
                {q.type === 'mcq' && q.options.map((opt,i)=> (
                  <label key={i} style={{display:'block'}}><input type="radio" name={q.id} onChange={()=>setAns(q.id,i)} /> <span style={{marginRight:8}}>{opt}</span></label>
                ))}
                {q.type === 'tf' && (
                  <div>
                    <label style={{display:'block'}}><input type="radio" name={q.id} onChange={()=>setAns(q.id,true)} /> <span style={{marginRight:8}}>صحيح</span></label>
                    <label style={{display:'block'}}><input type="radio" name={q.id} onChange={()=>setAns(q.id,false)} /> <span style={{marginRight:8}}>خطأ</span></label>
                  </div>
                )}
                {q.type === 'short' && (
                  <textarea style={{width:'100%',minHeight:80}} onChange={e=>setAns(q.id,e.target.value)} placeholder="اكتب إجابتك هنا..." />
                )}
              </div>
            </li>
          ))}
        </ol>
      </form>
    </div>
  )
}

function AdminPanel({grade, subject, onAddLesson, onAddTest, data}){
  const [lessonTitle, setLessonTitle] = useState('');
  const [lessonSummary, setLessonSummary] = useState('');
  const [testTitle, setTestTitle] = useState('');
  const [qText, setQText] = useState('');
  const [qType, setQType] = useState('mcq');
  const [mcqOpts, setMcqOpts] = useState(['','','','']);
  const [mcqAnswer, setMcqAnswer] = useState(0);

  function submitLesson(){
    if(!lessonTitle) return alert('أدخل عنوان الدرس');
    const lesson = { id: `${grade}-${subject}-L${Date.now()}`, title: lessonTitle, summary: lessonSummary };
    onAddLesson(lesson);
    setLessonTitle(''); setLessonSummary('');
  }

  function submitTest(){
    if(!testTitle) return alert('أدخل عنوان الاختبار');
    const q = qType === 'mcq' ? {
      id: `q-${Date.now()}`,
      type: 'mcq', question: qText, options: mcqOpts.slice(), answer: mcqAnswer
    } : qType === 'tf' ? { id: `q-${Date.now()}`, type: 'tf', question: qText, answer: true } : { id: `q-${Date.now()}`, type: 'short', question: qText, answer: '' };
    const test = { id: `t-${Date.now()}`, title: testTitle, questions: [q] };
    onAddTest(test);
    setTestTitle(''); setQText(''); setMcqOpts(['','','','']); setMcqAnswer(0);
  }

  return (
    <div style={{marginTop:16,background:'#fff',padding:12,borderRadius:8}}>
      <h3 style={{fontWeight:700}}>لوحة الإدارة — الصف {grade} — {subject}</h3>
      <div style={{display:'flex',gap:12,marginTop:12}}>
        <div style={{flex:1,border:'1px solid #e5e7eb',padding:12,borderRadius:6}}>
          <h4>أضف درساً</h4>
          <input style={{width:'100%',padding:8,marginTop:8}} placeholder="عنوان الدرس" value={lessonTitle} onChange={e=>setLessonTitle(e.target.value)} />
          <textarea style={{width:'100%',padding:8,marginTop:8}} placeholder="ملخص/محتوى" value={lessonSummary} onChange={e=>setLessonSummary(e.target.value)} />
          <div style={{marginTop:8}}><button onClick={submitLesson}>حفظ الدرس</button></div>
        </div>

        <div style={{flex:1,border:'1px solid #e5e7eb',padding:12,borderRadius:6}}>
          <h4>أضف اختباراً (سؤال واحد الآن)</h4>
          <input style={{width:'100%',padding:8,marginTop:8}} placeholder="عنوان الاختبار" value={testTitle} onChange={e=>setTestTitle(e.target.value)} />
          <select style={{width:'100%',padding:8,marginTop:8}} value={qType} onChange={e=>setQType(e.target.value)}>
            <option value="mcq">اختيار من متعدد</option>
            <option value="tf">صح/خطأ</option>
            <option value="short">إجابة قصيرة</option>
          </select>
          <textarea style={{width:'100%',padding:8,marginTop:8}} placeholder="نص السؤال" value={qText} onChange={e=>setQText(e.target.value)} />

          {qType === 'mcq' && (
            <div style={{marginTop:8}}>
              {mcqOpts.map((o,i)=> (
                <div key={i} style={{display:'flex',gap:8,alignItems:'center',marginTop:6}}>
                  <input style={{flex:1,padding:6}} placeholder={`خيار ${i+1}`} value={mcqOpts[i]} onChange={e=>{ const copy = mcqOpts.slice(); copy[i]=e.target.value; setMcqOpts(copy)}} />
                  <label>صح<input type="radio" name="mcqAns" checked={mcqAnswer===i} onChange={()=>setMcqAnswer(i)} /></label>
                </div>
              ))}
            </div>
          )}

          <div style={{marginTop:8}}><button onClick={submitTest}>إضافة الاختبار</button></div>
        </div>
      </div>

      <div style={{marginTop:12}}>
        <h4>معاينة بنك الأسئلة الحالي (مختصر)</h4>
        <div style={{marginTop:8,maxHeight:160,overflow:'auto',border:'1px solid #e5e7eb',padding:8,borderRadius:6}}>
          {data[grade] && data[grade][subject] ? (
            data[grade][subject].tests.slice(0,20).map(t=> (
              <div key={t.id} style={{marginBottom:8,padding:8,background:'#f9fafb',borderRadius:6}}>
                <div style={{fontWeight:600}}>{t.title}</div>
                <div style={{fontSize:12,color:'#6b7280'}}>أسئلة: {t.questions.length}</div>
              </div>
            ))
          ) : <div>لا توجد بيانات</div>}
        </div>
      </div>
    </div>
  )
}
